package com.capgemini.divya.dao;

import java.util.List;

import com.capgemini.divya.dto.GameBean;
import com.capgemini.divya.dto.UserBean;
import com.capgemini.divya.exception.GameException;

public interface IGameDAO 
{


	public void buyCard(UserBean user)
			throws GameException;
	
	public List<GameBean> getGameDetails() throws GameException;
}
