package com.capgemini.divya.service;

import java.util.List;

import com.capgemini.divya.dao.IGameDAO;
import com.capgemini.divya.dao.GameDAOImpl;
import com.capgemini.divya.dto.GameBean;
import com.capgemini.divya.dto.UserBean;
import com.capgemini.divya.exception.GameException;

/**
 *  Author : Divya Sharma
 *  Class Name : GameServiceImpl
 *  Package :com.capgemini.divya.service; 
 *  Date : Sept 25, 2017
 */
public class GameServiceImpl implements IGameService {
	IGameDAO gameDAO;

	public GameServiceImpl() {
		gameDAO = new GameDAOImpl();
	}

	@Override
	public void buyCard(UserBean user) throws GameException {
		// TODO Auto-generated method stub
		gameDAO.buyCard(user);
		
	}

	@Override
	public List<GameBean> getGameDetails() throws GameException{
		return gameDAO.getGameDetails();
	}
	
	
}
