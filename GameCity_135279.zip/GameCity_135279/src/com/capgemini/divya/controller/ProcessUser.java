package com.capgemini.divya.controller;

/*
 * ProcessUser servlet will dispatch control to different pages based upon the action parameter 
 */
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.divya.dto.GameBean;
import com.capgemini.divya.dto.UserBean;
import com.capgemini.divya.exception.GameException;
import com.capgemini.divya.service.GameServiceImpl;
import com.capgemini.divya.service.IGameService;

/**
 *  Author : Divya Sharma
 *  Class Name : ProcessUser
 *  Package :com.capgemini.divya.controller; 
 *  Date : Sept 25, 2017
 */
@WebServlet("/ProcessUser")
public class ProcessUser extends HttpServlet {

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// step 1:fetch parameter
		String action = request.getParameter("action");
		// step 2:RequestDispatcher object
		RequestDispatcher view = null;
		// step 3:IGameService object
		IGameService service = new GameServiceImpl();
		// step 4:HttpSession object with false as it has been re-directed from
		// jsp
		// Initial setting the session parameter to false
		HttpSession session = request.getSession(false);
		// action to fetch movie names available
		if (action != null && action.equalsIgnoreCase("addUser")) {
			try {

				view = getServletContext().getRequestDispatcher(
						"/pages/GameCity.jsp");
				view.forward(request, response);
			} catch (Exception e) {
				// dispatching control to error page
				request.setAttribute("errMsg", e.getMessage());
				view = getServletContext().getRequestDispatcher(
						"/pages/error.jsp");
				view.forward(request, response);
			}
		}

		// action to perform when user is added successfully
		if (action != null && action.equalsIgnoreCase("Buy Card")) {

			String name = request.getParameter("user_name");
			String address = request.getParameter("address");
			int cardAmt = Integer.parseInt(request.getParameter("card_amt")) - 100;
			UserBean user = new UserBean();

			user.setUserName(name);
			user.setAddress(address);
			user.setCardAmt(cardAmt);

			// if an existing session is not there, then creating a new one.
			if (session == null) {
				session = request.getSession(true);
			}
			session.setAttribute("UserBean", user);
			session.setAttribute("CardAmount", cardAmt);

			try {
				service.buyCard(user);
				List<GameBean> listGame = null;
				listGame = service.getGameDetails();
				session.setAttribute("GameList", listGame);
				view = getServletContext().getRequestDispatcher(
						"/pages/Play.jsp");
				view.forward(request, response);
			} catch (GameException e) {
				request.setAttribute("errMsg", e.getMessage());
				view = getServletContext().getRequestDispatcher(
						"/pages/error.jsp");
				view.forward(request, response);
			}
		}

		// action to allow the user to play the game for a particular game
		if (action != null && action.equalsIgnoreCase("Play")) {
			if (session != null) {

				int amount = Integer.parseInt(request.getParameter("amount"));

				GameBean gameBean = new GameBean();
				gameBean.setName(request.getParameter("game_name"));
				gameBean.setAmount(Integer.parseInt(request
						.getParameter("game_amount")));
				session.setAttribute("count", 1);
				if (gameBean.getAmount() < amount) {

					session.setAttribute("CardAmount",
							amount - gameBean.getAmount());
					session.setAttribute("GameName", gameBean.getName());

					view = getServletContext().getRequestDispatcher(
							"/pages/success.jsp");
					view.forward(request, response);
				} else {

					session.setAttribute("GameName", gameBean.getName());

					view = getServletContext().getRequestDispatcher(
							"/pages/Topup.jsp");
					view.forward(request, response);
				}

			} else {
				// dispatching control to error page if session is null
				request.setAttribute("errMsg", "Invalid Request");
				view = getServletContext().getRequestDispatcher(
						"/pages/error.jsp");
				view.forward(request, response);
			}
		}

		
	}

}
